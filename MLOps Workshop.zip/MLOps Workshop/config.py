# Databricks notebook source
# DBTITLE 1,Workshop configuration
# MAGIC %md
# MAGIC # MLOps Workshop Configuration
# MAGIC
# MAGIC Edit the values below to match your workspace. All workshop notebooks load this configuration via `_resources/00-setup`.
# MAGIC
# MAGIC * `catalog`: Unity Catalog catalog where workshop tables, functions and models are created (must exist, or you must have permission to create it)
# MAGIC * `db` / `dbName`: schema within the catalog (created if it does not exist)

# COMMAND ----------

# DBTITLE 1,Catalog and schema settings
# Unity Catalog location for all workshop assets - edit to match your workspace
catalog = "tnixon_fevm_catalog"
dbName = db = "dbdemos_mlops"